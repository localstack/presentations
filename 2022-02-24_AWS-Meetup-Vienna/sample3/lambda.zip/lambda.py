def hello(*args):
    print(args)
