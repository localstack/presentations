exports.hello = async (event, context) => {
    console.log("Hello from LocalStack!");
};
