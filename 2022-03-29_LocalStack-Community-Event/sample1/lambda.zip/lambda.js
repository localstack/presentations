exports.hello = async (event, context) => {
    console.log("Hello from LocalStack!");
    console.log(event);
};
