def handler(event, context):
    print("Hello from LocalStack!")

    list_buckets()

    return {"hello": "world"}


def list_buckets():
    import boto3
    client = boto3.client("s3")
    result = client.list_bucket()["Buckets"]
    print("Existing buckets:", result)
